<?php

namespace NFePHP\NFe\Tests;

use NFePHP\NFe\Complements;
use NFePHP\NFe\Tests\NFeTestCase;

class ComplementsTest extends NFeTestCase
{
    public function testToAuthorizeNfe()
    {
        //$nfeprotocoled = Complements::toAuthorize($request, $response);
    }
    
    public function testToAuthorizeInut()
    {
        
    }
    
    public function testToAuthorizeEvent()
    {
        
    }
    
    public function testToAuthorizeFailWrongDocument()
    {
        
    }
    
    public function testToAuthorizeFailNotXML()
    {
        
    }
    
    public function testToAuthorizeFailWrongNode()
    {
        
    }
    
    public function testCancelRegister()
    {
        
    }
    
    public function testCancelRegisterFailNotNFe()
    {
        
    }
    
    public function testB2B()
    {
        
    }

    public function testB2BFailNotNFe()
    {
        
    }

    public function testB2BFailWrongNode()
    {
        
    }
    
    
    
    
}
