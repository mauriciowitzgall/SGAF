# Changelog

All Notable changes to `sped-nfe` will be documented in this file.

Todas as atualizações a partir de 30/05/2016 devem observar os princípios [Mantendo o CHANGELOG](http://keepachangelog.com/).

## 5.0.0-dev 

## Notas da versão:
Esta release quebra a compatibilidade com as versões anteriores e contêm várias mudanças em relação a forma de configuração e uso.
### Added
- Nothing

### Deprecated
- Nothing

### Fixed
- Nothing

### Removed
- Nothing

### Security
- Nothing
