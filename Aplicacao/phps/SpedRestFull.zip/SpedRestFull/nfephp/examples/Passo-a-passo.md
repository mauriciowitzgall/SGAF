Documento com ordem para entendimento dos docs NFePHP
1- README.md
2- Config.md
3- Make.md
   Verificar se o ID (44 dígitos) da NFe deve ser gerado automaticamente ou ser controlado pelo nossos sistemas
4- Tools.md 
   Verificar tipo 55 ou 65 se qualquer um pode ser gerado








Tabela nfe_config
    "atualizacao" => "2017-11-27 21:25:00",
    "tpAmb" => 2,
    "razaosocial" => "FERNANDA WITZGALL ME",
    "cnpj" => "21996226000164",
    "siglaUF" => "RS",
    "schemes" => "PL008i2",
    "versao" => '3.10',
    "tokenIBPT" => "",
    "CSC" => "F8D212EF010646CA9B7048BA1707D335",
    "CSCid" => "000001",
    "model" => "55"

Tabela nfe_lancto
    id -> 44 digitos ... NFe00000..n