# DOWNLOAD DA NFe
Download de NF-e Confirmadas


**Função:** Serviço de Download da NF-e para uma determinada Chave de Acesso informada, para as NF-e confirmadas pelo destinatário.

**Processo:** síncrono.

**Método:** nfeDownloadNF
