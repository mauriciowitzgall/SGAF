# CONSULTA PELO RECIBO


**Função:** serviço destinado a retornar o resultado do processamento do lote de NF-e.

A mensagem de retorno poderá ser utilizada pela SEFAZ para enviar mensagens de interesse da SEFAZ para o emissor.

**Processo:** assíncrono.

**Método:** nfeRetAutorizacao

