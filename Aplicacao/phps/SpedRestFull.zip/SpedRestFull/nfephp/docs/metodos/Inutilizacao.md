# INUTILIZAÇÃO DE FAIXA DE NUMEROS DE NFe

**Função:** serviço destinado ao atendimento de solicitações de inutilização de numeração.

**Processo:** síncrono.

**Método:** nfeInutilizacao


