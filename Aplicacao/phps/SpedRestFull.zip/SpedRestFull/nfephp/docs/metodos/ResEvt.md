# DISTRIBUIÇÃO DE DOCUMENTOS FISCAIS



```xml
<?xml version="1.0"?>
<resEvento xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://www.portalfiscal.inf.br/nfe" versao="1.01">
  <cOrgao>91</cOrgao>
  <CNPJ>33683111000107</CNPJ>
  <chNFe>35161202663810000153550380000257021733208447</chNFe>
  <dhEvento>2016-12-22T19:55:44-02:00</dhEvento>
  <tpEvento>610600</tpEvento>
  <nSeqEvento>1</nSeqEvento>
  <xEvento>Registro de Autoriza&#xE7;&#xE3;o de CT-e para a NF-e</xEvento>
  <dhRecbto>2016-12-22T19:55:44-02:00</dhRecbto>
  <nProt>891161760045988</nProt>
</resEvento>
```

```
stdClass Object
(
    [attributes] => stdClass Object
        (
            [versao] => 1.01
        )

    [cOrgao] => 91
    [CNPJ] => 33683111000107
    [chNFe] => 35161202663810000153550380000257021733208447
    [dhEvento] => 2016-12-22T19:55:44-02:00
    [tpEvento] => 610600
    [nSeqEvento] => 1
    [xEvento] => Registro de Autorização de CT-e para a NF-e
    [dhRecbto] => 2016-12-22T19:55:44-02:00
    [nProt] => 891161760045988
)
```